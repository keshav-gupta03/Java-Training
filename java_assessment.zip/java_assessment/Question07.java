package java_assessment;

public class Question07 {
    public static void main(String[] args) {

    }
}
