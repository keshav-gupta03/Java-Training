package java_assessment;

public class Question11 {
    public static void main(String[] args) {

    }
}
//    The main difference between List and Set is that Set is unordered and contains different elements, whereas the list is ordered and can contain the same elements in it.
//# A List can contain the null and duplicate values
//It restricts us from entering the distinct value in it