package java_assessment;

public class Question10 {
    public static void main(String[] args) {

    }
}
//    The Major Difference between the HashMap and LinkedHashMap is the ordering of the elements. The LinkedHashMap provides a way to order and trace the elements
